<?php

namespace VersionPress\Utils;

class CompatibilityResult
{
    const COMPATIBLE = 'compatible';
    const UNTESTED = 'untested';
    const INCOMPATIBLE = 'incompatible';
    const VERSIONPRESS = 'versionpress';
}
